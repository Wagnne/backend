package com.backend.trabalhodejava.model;

import jakarta.persistence.*;

import java.util.UUID;

@Entity
@Table(name = "pessoas")
public class Pessoa {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private UUID id;

private String nome;

private String cpf;

private int idade;


    public UUID getId() {return id;}

    public void setId(UUID id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String name) {
        this.nome = name;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}
