package com.backend.trabalhodejava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhodejavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabalhodejavaApplication.class, args);
	}

}
