package com.backend.trabalhodejava.dto;

public record PessoaDto( String nome,String cpf,int idade) {
}
